package com.employee.springboot.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.employee.springboot.model.Employee;


@Repository
@Transactional
public class EmployeeDao {

	
	@PersistenceContext
	private EntityManager em;
	
	
	public boolean checkValueExists(String s) {
		
		if(s==null || s.isEmpty()) {
			return false;
		}
		else
			return true;
	}

	public List<Employee> getEmployee(Employee employee) {		
		
		String sql="select c from Employee c where ";
		StringBuilder sb= new StringBuilder(sql);
		
		boolean firstNameExists = checkValueExists(employee.getFirstName());
		boolean lastNameExists = checkValueExists(employee.getLastName());
		boolean emailExists = checkValueExists(employee.getEmail()); 
		
		if(firstNameExists) {
			sb.append("c.firstName like :firstName and ");
		}		
		
		if(lastNameExists) {
			sb.append("c.lastName like :lastName and ");
		}
		
		if(emailExists) {
			sb.append("c.email like :email and ");
		}
		sql  =sb.toString();
		
		if(firstNameExists || lastNameExists || emailExists) {
			sql =sql.substring(0,sql.length()-5);
		}
		else {
			sql =sql.substring(0,sql.length()-7);
		}
		
		System.out.println("final query "+sql);
		TypedQuery<Employee> query =em.createQuery(sql,Employee.class);
		
		if(firstNameExists) {
			query.setParameter("firstName", employee.getFirstName()+"%");
		}		
		
		if(lastNameExists) {
			query.setParameter("lastName", employee.getLastName()+"%");
		}
		
		if(emailExists) {
			query.setParameter("email", employee.getEmail()+"%");
		}		
		
		return query.getResultList();
	}
	
	
	
	
}
